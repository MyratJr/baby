from django.apps import AppConfig


class CvbuilderConfig(AppConfig):
    name = 'cvbuilder'
